import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.taskapp1.R
import com.example.taskapp1.Task

class TaskAdapter(
    private val tasks: MutableList<Task>,
    private val onEdit: (Task) -> Unit,
    private val onDelete: (Task) -> Unit
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    inner class TaskViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val nameTextView: TextView = view.findViewById(R.id.tv_name)
        val dateTextView: TextView = view.findViewById(R.id.tv_date)
        val taskTextView: TextView = view.findViewById(R.id.tv_task)
        val editButton: Button = view.findViewById(R.id.btn_edit)
        val deleteButton: Button = view.findViewById(R.id.btn_delete)

        fun bind(task: Task) {
            nameTextView.text = task.name
            dateTextView.text = task.date
            taskTextView.text = task.description

            editButton.setOnClickListener { onEdit(task) }
            deleteButton.setOnClickListener { onDelete(task) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_task, parent, false)
        return TaskViewHolder(view)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        holder.bind(tasks[position])
    }

    override fun getItemCount() = tasks.size
}
