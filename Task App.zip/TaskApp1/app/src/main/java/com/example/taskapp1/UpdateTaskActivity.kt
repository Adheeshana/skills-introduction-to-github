package com.example.taskapp1

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class UpdateTaskActivity : AppCompatActivity() {

    private lateinit var nameInput: EditText
    private lateinit var dateInput: EditText
    private lateinit var descriptionInput: EditText
    private lateinit var updateButton: Button
    private lateinit var task: Task

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.update_task)

        // Initialize views
        nameInput = findViewById(R.id.et_name)
        dateInput = findViewById(R.id.et_date)
        descriptionInput = findViewById(R.id.et_task)
        updateButton = findViewById(R.id.btn_update)

        // Get the task passed from TaskListActivity
        task = intent.getParcelableExtra("task") ?: throw IllegalArgumentException("Task not found")

        // Populate the input fields with existing task details
        nameInput.setText(task.name)
        dateInput.setText(task.date)
        descriptionInput.setText(task.description)

        updateButton.setOnClickListener {
            updateTask()
        }
    }

    private fun updateTask() {
        val sharedPreferences: SharedPreferences = getSharedPreferences("TaskDetails", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val gson = Gson()

        // Load existing tasks
        val tasksJson = sharedPreferences.getString("tasks", null)
        val tasks: MutableList<Task> = if (tasksJson != null) {
            gson.fromJson(tasksJson, object : TypeToken<MutableList<Task>>() {}.type) ?: mutableListOf()
        } else {
            mutableListOf()
        }

        // Find the index of the task to be updated
        val index = tasks.indexOfFirst { it.id == task.id }
        if (index != -1) {
            // Update task details
            tasks[index] = Task(
                id = task.id,
                name = nameInput.text.toString(),
                date = dateInput.text.toString(),
                description = descriptionInput.text.toString()
            )

            // Save the updated task list back to SharedPreferences
            editor.putString("tasks", gson.toJson(tasks))
            editor.apply()

            Toast.makeText(this, "Task updated!", Toast.LENGTH_SHORT).show()
            finish() // Close the activity and return to TaskListActivity
        } else {
            Toast.makeText(this, "Task not found!", Toast.LENGTH_SHORT).show()
        }
    }
}
