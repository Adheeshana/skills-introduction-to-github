package com.example.taskapp1

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class ReminderActivity : AppCompatActivity() {

    private lateinit var reminderMessageInput: EditText
    private lateinit var setReminderButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reminder)

        reminderMessageInput = findViewById(R.id.et_reminder_message)
        setReminderButton = findViewById(R.id.btn_set_reminder)

        setReminderButton.setOnClickListener { setReminder() }
    }

    private fun setReminder() {
        val reminderMessage = reminderMessageInput.text.toString()
        if (reminderMessage.isNotEmpty()) {
            val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(this, ReminderReceiver::class.java).apply {
                putExtra("REMINDER_MESSAGE", reminderMessage)
            }
            val pendingIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)

            val calendar = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 12) // Set the reminder time (12 PM for example)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
            }

            alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
            Toast.makeText(this, "Reminder set!", Toast.LENGTH_SHORT).show()
            finish() // Close activity after setting the reminder
        } else {
            Toast.makeText(this, "Please enter a reminder message", Toast.LENGTH_SHORT).show()
        }
    }
}
