package com.example.taskapp1

import TaskAdapter
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class TaskListActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var taskAdapter: TaskAdapter
    private var taskList: MutableList<Task> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_task_list)

        recyclerView = findViewById(R.id.recycler_view)
        taskAdapter = TaskAdapter(taskList, { task -> editTask(task) }, { task -> deleteTask(task) })
        recyclerView.adapter = taskAdapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        loadTasks()
    }

    private fun loadTasks() {
        val sharedPreferences: SharedPreferences = getSharedPreferences("TaskDetails", Context.MODE_PRIVATE)
        val gson = Gson()
        val tasksJson = sharedPreferences.getString("tasks", null)
        val tasks: MutableList<Task> = if (tasksJson != null) {
            gson.fromJson(tasksJson, object : TypeToken<MutableList<Task>>() {}.type) ?: mutableListOf()
        } else {
            mutableListOf()
        }
        taskList.clear()
        taskList.addAll(tasks)
        taskAdapter.notifyDataSetChanged()
    }

    private fun editTask(task: Task) {
        val intent = Intent(this, UpdateTaskActivity::class.java)
        intent.putExtra("task", task) // This is fine since Task implements Parcelable
        startActivity(intent)
    }

    private fun deleteTask(task: Task) {
        val sharedPreferences: SharedPreferences = getSharedPreferences("TaskDetails", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val gson = Gson()

        taskList.remove(task)
        editor.putString("tasks", gson.toJson(taskList))
        editor.apply()
        taskAdapter.notifyDataSetChanged()
    }

}
