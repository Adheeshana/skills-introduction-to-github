package com.example.taskapp1

import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class TimerActivity : AppCompatActivity() {

    private lateinit var timerTextView: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var resetButton: Button

    private var timer: CountDownTimer? = null
    private var timeInMillis: Long = 0L
    private var isTimerRunning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timer)

        timerTextView = findViewById(R.id.tv_timer)
        startButton = findViewById(R.id.btn_start)
        stopButton = findViewById(R.id.btn_stop)
        resetButton = findViewById(R.id.btn_reset)

        startButton.setOnClickListener { startTimer() }
        stopButton.setOnClickListener { stopTimer() }
        resetButton.setOnClickListener { resetTimer() }
    }

    private fun startTimer() {
        if (!isTimerRunning) {
            timeInMillis = 600000 // Set timer for 10 minutes (600000 ms)
            timer = object : CountDownTimer(timeInMillis, 1000) {
                override fun onTick(millisUntilFinished: Long) {
                    timeInMillis = millisUntilFinished
                    updateTimer()
                }

                override fun onFinish() {
                    isTimerRunning = false
                    timerTextView.text = "00:00:00"
                }
            }.start()

            isTimerRunning = true
        }
    }

    private fun stopTimer() {
        timer?.cancel()
        isTimerRunning = false
    }

    private fun resetTimer() {
        timer?.cancel()
        isTimerRunning = false
        timeInMillis = 0L
        timerTextView.text = "00:00:00"
    }

    private fun updateTimer() {
        val seconds = (timeInMillis / 1000).toInt() % 60
        val minutes = (timeInMillis / (1000 * 60) % 60)
        val hours = (timeInMillis / (1000 * 60 * 60) % 24)

        timerTextView.text = String.format("%02d:%02d:%02d", hours, minutes, seconds)
    }
}
