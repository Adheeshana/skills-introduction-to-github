package com.example.taskapp1

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import android.view.View
import android.widget.Button

class homepage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_homepage)

        // Initialize buttons
        val btnAddTask: Button = findViewById(R.id.btn_add_task)
        val btnMyTasks: Button = findViewById(R.id.btn_my_tasks)
        val btnTimer: Button = findViewById(R.id.btn_timer)
        val btnReminder: Button = findViewById(R.id.btn_reminder)

        // Set click listeners for each button
        btnAddTask.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java) // Replace with your Add Task activity name
            startActivity(intent)
        }

        btnMyTasks.setOnClickListener {
            val intent = Intent(this, TaskListActivity::class.java) // Replace with your Task List activity name
            startActivity(intent)
        }

        btnTimer.setOnClickListener {
            val intent = Intent(this, TimerActivity::class.java) // Open TimerActivity
            startActivity(intent)
        }

        btnReminder.setOnClickListener {
            val intent = Intent(this, ReminderActivity::class.java) // Open ReminderActivity
            startActivity(intent)
        }
    }
}
