package com.example.taskapp1

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val reminderMessage = intent.getStringExtra("REMINDER_MESSAGE")
        reminderMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show() // Show a toast notification for the reminder
        }
    }
}
