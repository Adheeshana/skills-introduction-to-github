package com.example.taskapp1

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken


class MainActivity : AppCompatActivity() {

    private lateinit var nameInput: EditText
    private lateinit var dateInput: EditText
    private lateinit var taskInput: EditText
    private lateinit var submitButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        nameInput = findViewById(R.id.et_name)
        dateInput = findViewById(R.id.et_date)
        taskInput = findViewById(R.id.et_task)
        submitButton = findViewById(R.id.btn_submit)

        // Set onClickListener for the submit button
        submitButton.setOnClickListener {
            val name = nameInput.text.toString()
            val date = dateInput.text.toString()
            val task = taskInput.text.toString()

            // Validate input fields
            if (name.isNotEmpty() && date.isNotEmpty() && task.isNotEmpty()) {
                // Save data to SharedPreferences
                saveTaskToSharedPreferences(name, date, task)

                // Optional: Show a Toast message
                Toast.makeText(this, "Task saved!", Toast.LENGTH_SHORT).show()

                // Clear input fields after saving
                clearFields()
            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun saveTaskToSharedPreferences(name: String, date: String, task: String) {
        val sharedPreferences: SharedPreferences = getSharedPreferences("TaskDetails", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val gson = Gson()

        // Load existing tasks
        val tasksJson = sharedPreferences.getString("tasks", null)
        val taskList: MutableList<Task> = if (tasksJson != null) {
            gson.fromJson(tasksJson, object : TypeToken<MutableList<Task>>() {}.type) ?: mutableListOf()
        } else {
            mutableListOf()
        }

        // Determine the next ID
        val nextId = if (taskList.isNotEmpty()) {
            taskList.maxOf { it.id } + 1 // Increment the highest existing ID
        } else {
            1 // Start from 1 if there are no tasks
        }

        // Add new task with the unique ID
        taskList.add(Task(nextId, name, date, task))

        // Save updated tasks list
        editor.putString("tasks", gson.toJson(taskList))
        editor.apply()
    }

    // Function to clear the input fields
    private fun clearFields() {
        nameInput.text.clear()
        dateInput.text.clear()
        taskInput.text.clear()
    }

}
